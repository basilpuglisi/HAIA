# CHANGELOG.md

## Version 1.1 – October 2025
### Summary
- Added validated ChatGPT deployment documentation.
- Introduced HAIA-SMART rubric as operational under HAIA-RECCLIN governance.
- Recorded baseline and revised scoring with confirmed responsiveness.

### Added Files
- `/docs/DEPLOYMENT_LOG_ChatGPT_v1.1.md`
- `/docs/VALIDATION_LOG_ChatGPT_FirstRun.md`
- `/docs/README_UPDATE_v1.1_LAUNCH.md`
- `/docs/SUMMARY_FOR_PUBLICATION.md`
