# HAIA-SMART Beta Testing Guidelines

**Goal:** Test whether patterns extracted from high‑performing content **predict** performance prospectively.

**Protocol (6 weeks):**
1) **Baseline (2 weeks):** Post normally. Track impressions, reach, engagement rate, profile views.
2) **Voice Calibration:** Adapt Writer’s Impression criteria to YOUR patterns.
3) **Implementation (4 weeks):** Apply HAIA‑SMART to every post; keep posting frequency constant; aim ≥ threshold.
4) **Compare:** Compute % change vs. baseline. Share anonymized results.

**Success criteria:**
- Individual: ≥25% improvement on 2+ metrics
- Community: ≥70% of participants achieve “meaningful improvement”

**Transparency:** All results published (positive, neutral, negative).

Details: **[docs/VALIDATION_PROTOCOL.md](docs/VALIDATION_PROTOCOL.md)** • **[docs/PATTERN_ANALYSIS.md](docs/PATTERN_ANALYSIS.md)**
