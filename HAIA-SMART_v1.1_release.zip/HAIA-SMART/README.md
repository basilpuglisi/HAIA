# HAIA-SMART

**Social Media AI Rating Tool for LinkedIn Content Optimization**

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-lightgrey.svg)](LICENSE.md)
[![Version](https://img.shields.io/badge/version-1.1-blue.svg)](docs/CHANGELOG.md)
[![Status](https://img.shields.io/badge/status-beta--testing-orange.svg)]()

**HAIA-SMART is a content scoring framework built by reverse‑engineering high‑performing LinkedIn posts.**
It **describes** patterns that worked historically and now seeks **prospective validation** to determine
if those patterns **predict** future success (correlation ≠ causation).

---

## 📊 Origin (What Happened)

**Observation window:** Sep 10 – Oct 7, 2025 (28 days) on Basil Puglisi’s LinkedIn  
**Observed change:** Impressions +648.6%, Members Reached +632.5%, Profile Views +236% (WoW)

Twenty posts from this period were analyzed to extract patterns across **Hook**, **Perceived Outperformance**,
**Writer’s Impression**, and **Call‑to‑Action Strength**. The rubric is descriptive, not a guarantee.

> These metrics predate the framework — they **informed** it. Charts = **source data** of pattern extraction.

![Content Performance During Analysis Period](assets/content_performance_28day.png)
![Profile Views During Analysis Period](assets/profile_views_28day.png)

---

## 🎯 What the Framework Does

Scores posts (1–5 each) on four pillars → total out of 20:
- **Hook Quality**: opening attention capture
- **Perceived Outperformance**: standout differentiation
- **Writer’s Impression**: authentic voice markers (calibratable)
- **Call‑to‑Action Strength**: activation toward next step

**Thresholds:** Technical/Proof ≥16, Commentary ≥15, Personal ≥14.  
**Important:** High score = “matches patterns.” Effectiveness must be tested.

---

## 🔬 Validation

- **Question:** Do the extracted patterns **predict** performance prospectively?
- **Protocol:** 2‑week baseline → 4‑week implementation with constant posting frequency
- **Individual success:** ≥25% improvement on 2+ metrics
- **Community validation:** ≥70% of participants achieve “meaningful improvement”

See **[BETA_TESTING.md](BETA_TESTING.md)** and **[docs/VALIDATION_PROTOCOL.md](docs/VALIDATION_PROTOCOL.md)**.

---

## 🚀 Quick Start (No install)

1) Copy **[MASTER_PROMPT_v1.1.md](MASTER_PROMPT_v1.1.md)** into ChatGPT/Claude/Gemini  
2) Paste your draft at the bottom, run scoring and iterate (≤3 cycles)  
3) Protect voice (calibrate if needed: **[docs/VOICE_CALIBRATION.md](docs/VOICE_CALIBRATION.md)**)  
4) Publish and track metrics

Docs: **[docs/PATTERN_ANALYSIS.md](docs/PATTERN_ANALYSIS.md)** • **[docs/FAQ.md](docs/FAQ.md)** • **[docs/CHANGELOG.md](docs/CHANGELOG.md)**

---

## 💼 License

- **Non‑commercial:** CC BY‑NC‑SA 4.0 (see **[LICENSE.md](LICENSE.md)**)  
- **Commercial:** Proprietary license required (contact via website)

---

## 👥 About

Author: **Basil Puglisi** — Human‑AI Collaboration Strategist & AI Governance Consultant  
Governance foundation: **HAIA‑RECCLIN** • Related: **Factics**, **Growth OS**

**Built from evidence. Awaiting validation. Honest about limitations.**
