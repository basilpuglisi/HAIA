# HAIA-SMART v1.1: Master Prompt

Copy this into ChatGPT/Claude/Gemini. Then paste your LinkedIn draft at the end.

Purpose: Score posts against patterns extracted from high‑performing content.  
Governance: Human decides what publishes (AI iterates ≤3 cycles).

## Instructions
1) Classify post: Technical / Commentary / Personal / Proof
2) Score 4 pillars (1–5): Hook, Outperformance, Voice, CTA (+1 provisional bonus to Hook if justified provocation)
3) Thresholds: Tech/Proof ≥16; Commentary ≥15; Personal ≥14; enforce min per‑pillar as needed
4) Priority (Basil default): Voice > Outperformance > CTA > Hook
5) Iterate up to 3 times; present best version + tone‑risk assessment

## Pillars (summary rubrics)
- **Hook**: 5=provocative/contrarian/bold/cultural+substance; 1=buried lede/platitude
- **Outperformance**: 5=fresh POV + concrete evidence + methodology transparency; 1=generic platitude
- **Writer’s Impression** (calibrate to your voice): core markers (opening pattern; structure; authority; rhetoric; tone). Zero‑dash rule is Basil‑specific—edit if not yours.
- **CTA**: 5=specific, thesis‑aligned action; 1=none

## Disambiguation
Evidence can score in Pillar 2 (differentiation) and/or Pillar 3 (methodology) depending on function.

## Output
- Scores with one‑sentence rationales
- Rewrites (if below threshold), then final recommended version
- Tone risk assessment (if Medium/High)
- Post‑publish KPIs to track (Views/Follower, comment depth, saves+shares, profile visits)

## Post Input
[Paste your draft below this line to begin analysis]
