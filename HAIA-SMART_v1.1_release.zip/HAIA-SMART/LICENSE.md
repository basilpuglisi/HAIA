# HAIA-SMART License

## For Non-Commercial Use

HAIA-SMART v1.1 (Social Media AI Rating Tool) is licensed under:

**Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)**

https://creativecommons.org/licenses/by-nc-sa/4.0/

### You are free to:

- **Share:** Copy and redistribute the material in any medium or format
- **Adapt:** Remix, transform, and build upon the material

### Under the following terms:

- **Attribution:** You must give appropriate credit to Basil Puglisi, provide a link to the license, and indicate if changes were made.
- **NonCommercial:** You may not use the material for commercial purposes.
- **ShareAlike:** If you remix, transform, or build upon the material, you must distribute your contributions under the same license.

### Proper Attribution Format (examples)

**Social posts**
```
Optimized using HAIA-SMART by Basil Puglisi
Framework: basilpuglisi.com | License: CC BY-NC-SA 4.0
```

**Blog/article**
```
This content was scored using HAIA-SMART, a LinkedIn content optimization framework
developed by Basil Puglisi (https://basilpuglisi.com). License: CC BY-NC-SA 4.0.
```

**Code header**
```python
# Content scored using HAIA-SMART v1.1
# Framework by Basil Puglisi (https://basilpuglisi.com)
# Licensed under CC BY-NC-SA 4.0
# Based on HAIA-RECCLIN governance methodology
```

**Academic**
```
Puglisi, B. (2025). HAIA-SMART: Social Media AI Rating Tool (v1.1) [Framework].
Retrieved from https://github.com/[REPO-PATH]
```

---

## For Commercial Use

All commercial applications require a separate proprietary license from Basil Puglisi.
Contact: https://basilpuglisi.com/contact  • Subject: "HAIA-SMART Commercial License Inquiry"

---

## Contributions

Contributions are welcome under CC BY-NC-SA 4.0. By contributing you agree your work
is licensed accordingly and that the author may offer commercial licenses for the
complete framework including contributions.

---

## Disclaimer

Provided “as is,” without warranties. **Status:** Beta testing phase. Built from
retrospective pattern analysis; prospective validation pending. No performance
guarantees. Users are responsible for content, compliance, and outcomes.

---

## Trademarks

“HAIA-SMART,” “HAIA-RECCLIN,” and “Factics” are trademarks of Basil Puglisi.

---

**Version:** 1.1  • **Last Updated:** October 2025
