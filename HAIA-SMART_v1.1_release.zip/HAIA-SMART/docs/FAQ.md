# FAQ

**Did HAIA‑SMART cause the 648% growth?** No. That success **preceded** the framework and was used to build it.

**Is this proven?** Not yet. We’re testing prospectively.

**Why release now?** To validate openly; results (good or bad) will be published.

**License?** Non‑commercial: CC BY‑NC‑SA 4.0. Commercial: proprietary license required.
