# Changelog

## v1.1 — Oct 2025
- Corrected causal framing (reverse‑engineered from observed success)
- Added beta testing + validation protocol docs
- Added voice calibration guide and assets
- Established dual licensing

## v1.0 — Sep 2025
- Internal draft
