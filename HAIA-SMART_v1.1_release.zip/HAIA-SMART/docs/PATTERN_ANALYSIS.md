# Pattern Extraction Methodology

**Source window:** Sep 10 – Oct 7, 2025 (20 posts).  
**Observed change:** Impressions +648.6%, Members Reached +632.5%, Profile Views +236% (WoW).  
**Process:** Analyzed openings (Hook), differentiation markers (Outperformance), voice patterns (Writer’s Impression),
and activation strategies (CTA). Built a 4‑pillar rubric that **describes** observed success.  
**Internal check:** Retrospective scoring aligned with higher engagement.  
**Limitations:** Single voice/time window; retrospective bias; potential confounders.  
**Next step:** Prospective validation (see Validation Protocol).

Replicate for your voice: analyze 10–20 high performers → codify patterns → test prospectively.
