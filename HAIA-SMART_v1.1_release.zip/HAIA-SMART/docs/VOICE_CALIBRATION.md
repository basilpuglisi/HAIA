# Voice Calibration Guide

1) Collect 10–20 of your own high‑performers.  
2) Extract YOUR openings, authority markers, structure, tone.  
3) Edit Writer’s Impression criteria in the Master Prompt to reflect YOUR patterns.  
4) Sanity‑check on past posts (they should score 4–5 on Voice).  
5) Avoid gaming—calibrate for accuracy, not inflation.
