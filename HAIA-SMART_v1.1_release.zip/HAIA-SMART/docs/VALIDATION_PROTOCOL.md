# Validation Protocol

**Research question:** Do posts scoring at/above thresholds outperform baseline when other variables (esp. frequency) are held constant?

**Design:**
- **Phase 1 (2 wks):** Baseline metrics; document frequency & engagement habits.
- **Phase 2:** Voice calibration.
- **Phase 3 (4 wks):** Systematic application; publish ≥ threshold (≤3 iterations); maintain frequency.
- **Phase 4:** Compare averages and % deltas; report anonymized results.

**Cohort targets:** ≥50 participants (≥30 minimum viable).  
**Validation bar:** ≥70% hit ≥25% improvement on ≥2 metrics.  
**Publishing:** All outcomes reported; refine or retire framework accordingly.
